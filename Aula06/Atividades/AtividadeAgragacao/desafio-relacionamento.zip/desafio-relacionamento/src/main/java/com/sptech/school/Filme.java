package com.sptech.school;

public class Filme {
    Integer id;
    String nome;
    String categoria;
    Double notaImdb;

    public Filme(Integer id, String nome, String categoria, Double notaImdb) {
        this.id = id;
        this.nome = nome;
        this.categoria = categoria;
        this.notaImdb = notaImdb;

    }
}
